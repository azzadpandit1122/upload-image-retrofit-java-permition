package com.example.upload_image_api.model;

import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Result implements Serializable, Parcelable {

    @SerializedName("imageName")
    @Expose
    private String imageName;
    @SerializedName("imageUrl")
    @Expose
    private String imageUrl;
    @SerializedName("imageLqThumbName")
    @Expose
    private String imageLqThumbName;
    @SerializedName("imageLqThumbUrl")
    @Expose
    private String imageLqThumbUrl;
    @SerializedName("imageSizes")
    @Expose
    private List<ImageSize> imageSizes = null;
    @SerializedName("isMultisizeImg")
    @Expose
    private Integer isMultisizeImg;
    @SerializedName("isWebP")
    @Expose
    private Integer isWebP;
    public final static Creator<Result> CREATOR = new Creator<Result>() {


        @SuppressWarnings({
                "unchecked"
        })
        public Result createFromParcel(android.os.Parcel in) {
            return new Result(in);
        }

        public Result[] newArray(int size) {
            return (new Result[size]);
        }

    };
    private final static long serialVersionUID = -2405576438339818347L;

    protected Result(android.os.Parcel in) {
        this.imageName = ((String) in.readValue((String.class.getClassLoader())));
        this.imageUrl = ((String) in.readValue((String.class.getClassLoader())));
        this.imageLqThumbName = ((String) in.readValue((String.class.getClassLoader())));
        this.imageLqThumbUrl = ((String) in.readValue((String.class.getClassLoader())));
        in.readList(this.imageSizes, (ImageSize.class.getClassLoader()));
        this.isMultisizeImg = ((Integer) in.readValue((Integer.class.getClassLoader())));
        this.isWebP = ((Integer) in.readValue((Integer.class.getClassLoader())));
    }

    public Result() {
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageLqThumbName() {
        return imageLqThumbName;
    }

    public void setImageLqThumbName(String imageLqThumbName) {
        this.imageLqThumbName = imageLqThumbName;
    }

    public String getImageLqThumbUrl() {
        return imageLqThumbUrl;
    }

    public void setImageLqThumbUrl(String imageLqThumbUrl) {
        this.imageLqThumbUrl = imageLqThumbUrl;
    }

    public List<ImageSize> getImageSizes() {
        return imageSizes;
    }

    public void setImageSizes(List<ImageSize> imageSizes) {
        this.imageSizes = imageSizes;
    }

    public Integer getIsMultisizeImg() {
        return isMultisizeImg;
    }

    public void setIsMultisizeImg(Integer isMultisizeImg) {
        this.isMultisizeImg = isMultisizeImg;
    }

    public Integer getIsWebP() {
        return isWebP;
    }

    public void setIsWebP(Integer isWebP) {
        this.isWebP = isWebP;
    }

    public void writeToParcel(android.os.Parcel dest, int flags) {
        dest.writeValue(imageName);
        dest.writeValue(imageUrl);
        dest.writeValue(imageLqThumbName);
        dest.writeValue(imageLqThumbUrl);
        dest.writeList(imageSizes);
        dest.writeValue(isMultisizeImg);
        dest.writeValue(isWebP);
    }

    public int describeContents() {
        return 0;
    }

}
