package com.example.upload_image_api.model;

import java.io.Serializable;
import java.util.List;

import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ImageSize implements Serializable, Parcelable
{

@SerializedName("name")
@Expose
private String name;
@SerializedName("width")
@Expose
private Integer width;
public final static Creator<ImageSize> CREATOR = new Creator<ImageSize>() {


@SuppressWarnings({
"unchecked"
})
public ImageSize createFromParcel(android.os.Parcel in) {
return new ImageSize(in);
}

public ImageSize[] newArray(int size) {
return (new ImageSize[size]);
}

}
;
private final static long serialVersionUID = 7976265217869187658L;

protected ImageSize(android.os.Parcel in) {
this.name = ((String) in.readValue((String.class.getClassLoader())));
this.width = ((Integer) in.readValue((Integer.class.getClassLoader())));
}

public ImageSize() {
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public Integer getWidth() {
return width;
}

public void setWidth(Integer width) {
this.width = width;
}

public void writeToParcel(android.os.Parcel dest, int flags) {
dest.writeValue(name);
dest.writeValue(width);
}

public int describeContents() {
return 0;
}

}

