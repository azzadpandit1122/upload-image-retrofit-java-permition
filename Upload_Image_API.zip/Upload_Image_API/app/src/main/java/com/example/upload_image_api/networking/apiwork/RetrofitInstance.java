package com.example.upload_image_api.networking.apiwork;

import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionPool;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitInstance {

    public static String BASE_URL = "https://sapna.dev.nojoto.com/";
    public static String BASE_URL_Local = "https://b596-122-161-89-74.in.ngrok.io/api/v1/";
    static Retrofit retrofit;

    public static Retrofit getRetrofit(){
        if(retrofit == null){
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(getOkHttpClient())
                    .client(getOkHttpClientToken())
                    .addConverterFactory(GsonConverterFactory.create())
                    .addConverterFactory(GsonConverterFactory.create(new GsonBuilder().serializeNulls().create()))
                    .build();
        }
        return retrofit;
    }

    static Retrofit retrofitlocal;


    public static Retrofit getRetrofitlocal() {
        if (retrofitlocal == null) {
            retrofitlocal = new Retrofit.Builder()
                    .baseUrl(BASE_URL_Local)
                    .client(getOkHttpClient())
                    .client(getOkHttpClientToken())
                    .addConverterFactory(GsonConverterFactory.create()).build();
        }
        return retrofitlocal;
    }

    private static OkHttpClient getOkHttpClientToken() {
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request newRequest  = chain.request().newBuilder()
                        .addHeader("Authorization", "Bearer " + "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vZGV2LmJlLm9wdGl1bS5jby5pbi9hcGkvdjEvdXNlci9sb2dpbiIsImlhdCI6MTY2NzI3NTkwMCwiZXhwIjoxNjk4ODMzNTAwLCJuYmYiOjE2NjcyNzU5MDAsImp0aSI6InpVR3JvbEVvWGR4ajJSU3QiLCJzdWIiOjEyLCJwcnYiOiIyM2JkNWM4OTQ5ZjYwMGFkYjM5ZTcwMWM0MDA4NzJkYjdhNTk3NmY3In0.qwAGMHItLhW69gVJSySGjkRqFB2xZxzEEv9t8UImw2Q")
                        .build();
                return chain.proceed(newRequest);
            }
        }).build();
        return  client;
    }


    private static OkHttpClient getOkHttpClient() {

        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .retryOnConnectionFailure(true);
        //Print Log
        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(httpLoggingInterceptor);
        builder.connectionPool(new ConnectionPool(0, 5, TimeUnit.MINUTES));
        return builder.readTimeout(15, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .build();

    }

}
