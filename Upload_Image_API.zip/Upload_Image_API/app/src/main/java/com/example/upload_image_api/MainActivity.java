package com.example.upload_image_api;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import com.example.upload_image_api.databinding.ActivityMainBinding;
import com.example.upload_image_api.model.UploadResponse;
import com.example.upload_image_api.networking.apiwork.API_Interface;
import com.example.upload_image_api.networking.apiwork.RetrofitInstance;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {


    ActivityMainBinding binding;
    private static final int click_img = 123;
    String currentPhotoPath;
    MultipartBody.Part filePart ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.picImage.setOnClickListener(view -> {
            uploadImage();
        });
    }

    private void uploadImage() {
        ActivityCompat.requestPermissions(MainActivity.this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    attachmentTakePictureIntent(123);
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == click_img) {
            if (resultCode == Activity.RESULT_OK) {
                File f = new File(currentPhotoPath);
                filePart = MultipartBody.Part.createFormData("image", f.getName(), RequestBody.create(MediaType.parse("file/*"), f));
                binding.urlLocal.setText(currentPhotoPath);
                callApi(filePart);
            } else {
                //validate = false;
            }
        }
    }

    private void callApi(MultipartBody.Part filePart) {
        API_Interface api_interface = RetrofitInstance.getRetrofit().create(API_Interface.class);
        api_interface.uploadImage("7ec99b415af3e88205250e3514ce0fa7","media",filePart).enqueue(new Callback<UploadResponse>() {
            @Override
            public void onResponse(Call<UploadResponse> call, Response<UploadResponse> response) {
               if (response.isSuccessful()){
                   if (response.code()==200){
                       binding.respons.setText(response.body().getDescription().toString());
                       Toast.makeText(MainActivity.this, ""+response.message(), Toast.LENGTH_SHORT).show();

                   }

               }
            }
            @Override
            public void onFailure(Call<UploadResponse> call, Throwable t) {
            binding.respons.setText(t.getLocalizedMessage());
            }
        });


    }

    private void attachmentTakePictureIntent(int attach_id) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getApplicationContext().getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(getApplicationContext(), "com.example.upload_image_api.provider", photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, attach_id);
            }
        } else {

        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */);

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }



}