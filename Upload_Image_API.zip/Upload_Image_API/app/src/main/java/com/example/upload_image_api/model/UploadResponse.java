package com.example.upload_image_api.model;

import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class UploadResponse{

    private Boolean success;
    private Integer statusCode;
    private Boolean error;
    private String message;
    private String description;
    private String cid;

    public UploadResponse(Boolean success, Integer statusCode, Boolean error, String message, String description, String cid) {
        this.success = success;
        this.statusCode = statusCode;
        this.error = error;
        this.message = message;
        this.description = description;
        this.cid = cid;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getError() {
        return error;
    }

    public void setError(Boolean error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }
}
